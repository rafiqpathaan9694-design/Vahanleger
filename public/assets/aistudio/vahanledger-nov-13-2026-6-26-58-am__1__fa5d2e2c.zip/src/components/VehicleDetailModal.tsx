import React, { useEffect, useMemo, useState } from 'react';
import {
  Building2,
  Calendar,
  Check,
  Edit3,
  Phone,
  Play,
  Printer,
  Share2,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import {
  formatBytes,
  formatDisplayDateTime,
  type MediaRecord,
  type VehicleRecord,
} from '../types';
import { getMediaByIds } from '../db/storage';

interface VehicleDetailModalProps {
  record: VehicleRecord;
  onClose: () => void;
  onEdit: (record: VehicleRecord) => void;
  onDelete: (record: VehicleRecord) => Promise<void>;
}

const SHARE_BAR_COLORS = [
  'bg-blue-700',
  'bg-slate-700',
  'bg-emerald-600',
  'bg-amber-600',
  'bg-indigo-600',
  'bg-cyan-700',
  'bg-rose-600',
  'bg-teal-700',
  'bg-sky-700',
  'bg-slate-500',
];

export const VehicleDetailModal: React.FC<VehicleDetailModalProps> = ({
  record,
  onClose,
  onEdit,
  onDelete,
}) => {
  const [media, setMedia] = useState<MediaRecord[]>([]);
  const [loadingMedia, setLoadingMedia] = useState(false);
  const [activeMedia, setActiveMedia] = useState<MediaRecord | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (record.mediaIds.length === 0) {
      setMedia([]);
      return;
    }
    let active = true;
    setLoadingMedia(true);
    getMediaByIds(record.mediaIds)
      .then((res) => {
        if (active) setMedia(res);
      })
      .finally(() => {
        if (active) setLoadingMedia(false);
      });
    return () => {
      active = false;
    };
  }, [record]);

  const mediaUrls = useMemo(() => {
    return media.map((m) => ({
      id: m.id,
      url: URL.createObjectURL(m.blob),
    }));
  }, [media]);

  useEffect(() => {
    return () => {
      mediaUrls.forEach((u) => URL.revokeObjectURL(u.url));
    };
  }, [mediaUrls]);

  const urlMap = useMemo(() => {
    const map = new Map<string, string>();
    mediaUrls.forEach((u) => map.set(u.id, u.url));
    return map;
  }, [mediaUrls]);

  const buildShareText = () => {
    const partnersText = record.partners
      .map((p, idx) => `  ${idx + 1}. ${p.name} — ${p.percentage}%`)
      .join('\n');
    return [
      `Vehicle Record: ${record.vehicleNumber}`,
      `Customer: ${record.customerName}${record.customerPhone ? ` (${record.customerPhone})` : ''}`,
      `Finance Bank: ${record.bankName}`,
      `Partners (${record.partnerCount}):`,
      partnersText,
      `Date & Time: ${formatDisplayDateTime(record.dateTime)}`,
      record.notes ? `Notes: ${record.notes}` : null,
      media.length > 0 ? `Attachments: ${media.length} media file(s)` : null,
    ]
      .filter(Boolean)
      .join('\n');
  };

  const handleShare = async () => {
    const text = buildShareText();
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Vehicle ${record.vehicleNumber}`,
          text,
        });
        return;
      } catch {
        // User cancelled or share unsupported, fallback to copy
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore clipboard errors
    }
  };

  const handleDeleteConfirm = async () => {
    setDeleting(true);
    try {
      await onDelete(record);
      onClose();
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs p-0 sm:p-4"
      onClick={onClose}
    >
      <div
        className="flex max-h-[94dvh] w-full sm:max-w-2xl flex-col rounded-t-3xl sm:rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-200 px-5 py-4 shrink-0">
          <div>
            <p className="text-xs font-medium text-slate-500">Vehicle Record</p>
            <h2 className="mt-0.5 font-mono text-2xl font-bold tracking-wider text-slate-900">
              {record.vehicleNumber}
            </h2>
          </div>
          <div className="flex items-center gap-1.5 no-print">
            <button
              type="button"
              onClick={handleShare}
              className="flex h-11 items-center gap-1.5 rounded-xl border border-slate-200 px-3 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
              title="Share or copy summary"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 text-emerald-600" />
                  <span className="text-emerald-700">Copied</span>
                </>
              ) : (
                <>
                  <Share2 className="h-4 w-4" />
                  <span className="hidden sm:inline">Share</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="hidden sm:flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
              title="Print / Save PDF"
              aria-label="Print record"
            >
              <Printer className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-colors"
              aria-label="Close detail"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-5 py-5 space-y-6">
          {/* Primary Info Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-xs font-medium text-slate-500">Customer Name</p>
              <p className="text-base font-bold text-slate-900">
                {record.customerName}
              </p>
              {record.customerPhone && (
                <a
                  href={`tel:${record.customerPhone}`}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-700 hover:underline pt-0.5 font-mono"
                >
                  <Phone className="h-3.5 w-3.5" />
                  <span>{record.customerPhone}</span>
                </a>
              )}
            </div>

            <div className="space-y-1">
              <p className="text-xs font-medium text-slate-500">Finance Bank</p>
              <div className="flex items-center gap-2 text-base font-semibold text-slate-900">
                <Building2 className="h-4 w-4 text-slate-400 shrink-0" />
                <span>{record.bankName}</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-500 tabular-nums pt-0.5">
                <Calendar className="h-3.5 w-3.5 text-slate-400" />
                <span>{formatDisplayDateTime(record.dateTime)}</span>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100" />

          {/* Partners / Shareholding Breakdown */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-blue-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  Ownership Shareholding
                </h3>
              </div>
              <span className="text-xs font-semibold text-slate-600 tabular-nums">
                {record.partnerCount}{' '}
                {record.partnerCount === 1 ? 'Partner' : 'Partners'}
              </span>
            </div>

            {/* Stacked Proportion Bar */}
            <div className="flex h-3 w-full overflow-hidden rounded-full bg-slate-100">
              {record.partners.map((p, idx) => (
                <div
                  key={p.id}
                  style={{ width: `${p.percentage}%` }}
                  className={`${SHARE_BAR_COLORS[idx % SHARE_BAR_COLORS.length]} transition-all`}
                  title={`${p.name}: ${p.percentage}%`}
                />
              ))}
            </div>

            <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-slate-50/50">
              {record.partners.map((partner, idx) => (
                <div
                  key={partner.id}
                  className="flex items-center justify-between px-4 py-3 text-sm"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className={`h-2.5 w-2.5 rounded-full shrink-0 ${
                        SHARE_BAR_COLORS[idx % SHARE_BAR_COLORS.length]
                      }`}
                    />
                    <span className="font-medium text-slate-900 truncate">
                      {partner.name}
                    </span>
                  </div>
                  <span className="font-mono font-bold text-slate-900 tabular-nums shrink-0">
                    {partner.percentage}%
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Notes */}
          {record.notes && (
            <div className="space-y-1.5">
              <h3 className="text-xs font-semibold text-slate-500">Notes</h3>
              <p className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 whitespace-pre-wrap">
                {record.notes}
              </p>
            </div>
          )}

          {/* Media Gallery */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                Attached Photos &amp; Videos
              </h3>
              <span className="text-xs font-medium text-slate-500 tabular-nums">
                {media.length} {media.length === 1 ? 'item' : 'items'}
              </span>
            </div>

            {loadingMedia ? (
              <p className="text-xs text-slate-500">Loading attachments...</p>
            ) : media.length === 0 ? (
              <p className="rounded-xl border border-dashed border-slate-200 py-6 text-center text-xs text-slate-500">
                No photos or videos attached to this vehicle entry.
              </p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {media.map((item) => {
                  const url = urlMap.get(item.id);
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveMedia(item)}
                      className="group relative overflow-hidden rounded-xl border border-slate-200 bg-slate-100 aspect-4/3 text-left focus:outline-none focus:ring-2 focus:ring-blue-700"
                    >
                      {item.type === 'image' && url ? (
                        <img
                          src={url}
                          alt={item.name}
                          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-200"
                          referrerPolicy="no-referrer"
                        />
                      ) : url ? (
                        <div className="relative h-full w-full bg-slate-900">
                          <video
                            src={url}
                            className="h-full w-full object-cover opacity-85"
                            muted
                            playsInline
                          />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-slate-950/75 text-white">
                              <Play className="h-5 w-5 fill-current ml-0.5" />
                            </div>
                          </div>
                        </div>
                      ) : null}
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 via-black/30 to-transparent px-2.5 py-1.5">
                        <p className="truncate text-[11px] font-medium text-white tabular-nums">
                          {item.type === 'video' ? 'Video' : 'Photo'} · {formatBytes(item.size)}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between gap-3 border-t border-slate-200 bg-white px-5 py-3.5 pb-safe shrink-0 no-print">
          {confirmDelete ? (
            <div className="flex w-full items-center justify-between gap-2">
              <span className="text-xs font-semibold text-red-700">
                Delete this record permanently?
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="rounded-xl border border-slate-300 px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 min-h-[44px]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={deleting}
                  onClick={handleDeleteConfirm}
                  className="rounded-xl bg-red-600 px-4 py-2 text-xs font-semibold text-white hover:bg-red-700 min-h-[44px]"
                >
                  {deleting ? 'Deleting...' : 'Confirm Delete'}
                </button>
              </div>
            </div>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="inline-flex items-center gap-1.5 rounded-xl border border-red-200 bg-red-50/60 px-4 py-2.5 text-sm font-semibold text-red-700 hover:bg-red-100 transition-colors min-h-[46px]"
              >
                <Trash2 className="h-4 w-4" />
                <span>Delete</span>
              </button>
              <button
                type="button"
                onClick={() => onEdit(record)}
                className="inline-flex flex-1 sm:flex-none items-center justify-center gap-2 rounded-xl bg-slate-900 px-6 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 transition-colors min-h-[46px]"
              >
                <Edit3 className="h-4 w-4" />
                <span>Edit Record</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Fullscreen Media Viewer */}
      {activeMedia && urlMap.get(activeMedia.id) && (
        <div
          className="fixed inset-0 z-[60] flex flex-col bg-slate-950/95 p-4"
          onClick={() => setActiveMedia(null)}
        >
          <div className="flex items-center justify-between text-white pb-3">
            <span className="text-sm font-medium truncate">
              {record.vehicleNumber} — {activeMedia.name}
            </span>
            <button
              type="button"
              onClick={() => setActiveMedia(null)}
              className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 text-white hover:bg-white/20"
              aria-label="Close media viewer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div
            className="flex-1 flex items-center justify-center overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {activeMedia.type === 'image' ? (
              <img
                src={urlMap.get(activeMedia.id)}
                alt={activeMedia.name}
                className="max-h-full max-w-full rounded-xl object-contain"
                referrerPolicy="no-referrer"
              />
            ) : (
              <video
                src={urlMap.get(activeMedia.id)}
                controls
                autoPlay
                playsInline
                className="max-h-full max-w-full rounded-xl"
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
};
