import React, { useEffect, useMemo, useRef } from 'react';
import { Camera, Film, FolderOpen, Play, Trash2 } from 'lucide-react';
import { formatBytes, type MediaRecord } from '../types';

export interface DraftMediaItem {
  id: string;
  type: 'image' | 'video';
  name: string;
  mimeType: string;
  size: number;
  createdAt: number;
  blob: Blob;
  isNew: boolean;
}

interface MediaCaptureSectionProps {
  items: DraftMediaItem[];
  onAddFiles: (files: FileList) => void;
  onRemoveItem: (id: string) => void;
}

export const MediaCaptureSection: React.FC<MediaCaptureSectionProps> = ({
  items,
  onAddFiles,
  onRemoveItem,
}) => {
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const previews = useMemo(() => {
    return items.map((item) => ({
      id: item.id,
      url: URL.createObjectURL(item.blob),
    }));
  }, [items]);

  useEffect(() => {
    return () => {
      previews.forEach((p) => URL.revokeObjectURL(p.url));
    };
  }, [previews]);

  const urlMap = useMemo(() => {
    const map = new Map<string, string>();
    previews.forEach((p) => map.set(p.id, p.url));
    return map;
  }, [previews]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onAddFiles(e.target.files);
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="block text-sm font-semibold text-slate-900">
          Photos &amp; Videos
        </label>
        <span className="text-xs font-medium text-slate-500 tabular-nums">
          {items.length} {items.length === 1 ? 'file' : 'files'} attached
        </span>
      </div>

      {/* Hidden inputs for Camera Photo, Camera Video, and Gallery */}
      <input
        ref={photoInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*,video/*"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Capture / Upload Buttons — 44px+ touch targets */}
      <div className="grid grid-cols-3 gap-2.5">
        <button
          type="button"
          onClick={() => photoInputRef.current?.click()}
          className="flex flex-col items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-xs font-semibold text-slate-800 hover:bg-slate-100 active:scale-[0.98] transition min-h-[68px]"
        >
          <Camera className="h-5 w-5 text-blue-700" />
          <span className="whitespace-nowrap">Take Photo</span>
        </button>

        <button
          type="button"
          onClick={() => videoInputRef.current?.click()}
          className="flex flex-col items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-xs font-semibold text-slate-800 hover:bg-slate-100 active:scale-[0.98] transition min-h-[68px]"
        >
          <Film className="h-5 w-5 text-blue-700" />
          <span className="whitespace-nowrap">Record Video</span>
        </button>

        <button
          type="button"
          onClick={() => galleryInputRef.current?.click()}
          className="flex flex-col items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-xs font-semibold text-slate-800 hover:bg-slate-100 active:scale-[0.98] transition min-h-[68px]"
        >
          <FolderOpen className="h-5 w-5 text-blue-700" />
          <span className="whitespace-nowrap">Gallery</span>
        </button>
      </div>

      {/* Preview Grid */}
      {items.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
          {items.map((item) => {
            const url = urlMap.get(item.id);
            return (
              <div
                key={item.id}
                className="group relative overflow-hidden rounded-xl border border-slate-200 bg-slate-100 aspect-4/3"
              >
                {item.type === 'image' && url ? (
                  <img
                    src={url}
                    alt={item.name}
                    className="h-full w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : url ? (
                  <div className="relative h-full w-full bg-slate-900">
                    <video
                      src={url}
                      className="h-full w-full object-cover opacity-85"
                      muted
                      playsInline
                    />
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-950/70 text-white">
                        <Play className="h-4 w-4 fill-current ml-0.5" />
                      </div>
                    </div>
                  </div>
                ) : null}

                {/* Scrim & file size */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 via-black/30 to-transparent px-2.5 py-1.5">
                  <p className="truncate text-[11px] font-medium text-white tabular-nums">
                    {item.type === 'video' ? 'Video' : 'Photo'} · {formatBytes(item.size)}
                  </p>
                </div>

                {/* Remove button with 44px touch target area */}
                <button
                  type="button"
                  onClick={() => onRemoveItem(item.id)}
                  className="absolute top-1 right-1 flex h-9 w-9 items-center justify-center rounded-lg bg-slate-950/75 text-white hover:bg-red-600 transition-colors"
                  aria-label={`Remove ${item.name}`}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export function mediaRecordToDraft(rec: MediaRecord): DraftMediaItem {
  return {
    ...rec,
    isNew: false,
  };
}
