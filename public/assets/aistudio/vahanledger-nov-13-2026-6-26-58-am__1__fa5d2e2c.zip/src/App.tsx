import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Building2,
  Car,
  ChevronRight,
  Download,
  Image as ImageIcon,
  Layers,
  Plus,
  Search,
  Users,
  Video,
  WifiOff,
} from 'lucide-react';
import {
  deleteRecordAndMedia,
  getAllMediaSummary,
  getAllRecords,
  saveRecordWithMedia,
} from './db/storage';
import { useOnlineStatus } from './hooks/usePWAInstall';
import {
  formatDisplayDateTime,
  type MediaRecord,
  type VehicleRecord,
} from './types';
import { PWAInstallButton } from './components/PWAInstallButton';
import { VehicleFormModal } from './components/VehicleFormModal';
import { VehicleDetailModal } from './components/VehicleDetailModal';

type NavView = 'records' | 'joint' | 'banks';

export default function App() {
  const isOnline = useOnlineStatus();

  const [records, setRecords] = useState<VehicleRecord[]>([]);
  const [mediaSummary, setMediaSummary] = useState<
    Record<string, { images: number; videos: number }>
  >({});
  const [loading, setLoading] = useState(true);

  const [activeView, setActiveView] = useState<NavView>('records');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBankFilter, setSelectedBankFilter] = useState<string>('ALL');

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<VehicleRecord | null>(null);
  const [viewingRecord, setViewingRecord] = useState<VehicleRecord | null>(null);

  const loadData = useCallback(async () => {
    try {
      const [recs, summary] = await Promise.all([
        getAllRecords(),
        getAllMediaSummary(),
      ]);
      setRecords(recs);
      setMediaSummary(summary);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSaveRecord = async (
    record: VehicleRecord,
    newMedia: MediaRecord[],
    removedMediaIds: string[]
  ) => {
    await saveRecordWithMedia(record, newMedia, removedMediaIds);
    await loadData();
    if (viewingRecord && viewingRecord.id === record.id) {
      setViewingRecord(record);
    }
  };

  const handleDeleteRecord = async (record: VehicleRecord) => {
    await deleteRecordAndMedia(record);
    await loadData();
  };

  const uniqueBanks = useMemo(() => {
    const map = new Map<string, number>();
    for (const r of records) {
      map.set(r.bankName, (map.get(r.bankName) ?? 0) + 1);
    }
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [records]);

  const stats = useMemo(() => {
    let jointCount = 0;
    let totalMedia = 0;
    for (const r of records) {
      if (r.partnerCount > 1) jointCount += 1;
      totalMedia += r.mediaIds.length;
    }
    return {
      total: records.length,
      banks: uniqueBanks.length,
      joint: jointCount,
      media: totalMedia,
    };
  }, [records, uniqueBanks]);

  const filteredRecords = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return records.filter((r) => {
      if (activeView === 'joint' && r.partnerCount < 2) return false;
      if (selectedBankFilter !== 'ALL' && r.bankName !== selectedBankFilter) {
        return false;
      }
      if (!q) return true;
      const inVehicle = r.vehicleNumber.toLowerCase().includes(q);
      const inCustomer = r.customerName.toLowerCase().includes(q);
      const inBank = r.bankName.toLowerCase().includes(q);
      const inPartner = r.partners.some((p) => p.name.toLowerCase().includes(q));
      return inVehicle || inCustomer || inBank || inPartner;
    });
  }, [records, activeView, selectedBankFilter, searchQuery]);

  const handleExportJSON = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      totalRecords: records.length,
      records,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vahanledger-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const openNewForm = () => {
    setEditingRecord(null);
    setIsFormOpen(true);
  };

  const openEditForm = (rec: VehicleRecord) => {
    setViewingRecord(null);
    setEditingRecord(rec);
    setIsFormOpen(true);
  };

  return (
    <div className="min-h-dvh flex flex-col bg-slate-50 text-slate-900">
      {/* Desktop Top Bar (3-zone contract) */}
      <header className="hidden md:flex sticky top-0 z-30 items-center justify-between gap-8 border-b border-slate-200 bg-white/90 backdrop-blur-md px-6 lg:px-10 h-16 no-print">
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveView('records');
            setSelectedBankFilter('ALL');
          }}
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
        >
          VahanLedger
        </a>

        <nav className="flex items-center gap-7 text-sm font-medium text-slate-600">
          <button
            type="button"
            onClick={() => {
              setActiveView('records');
              setSelectedBankFilter('ALL');
            }}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
              activeView === 'records'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            All Vehicles
          </button>
          <button
            type="button"
            onClick={() => setActiveView('joint')}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
              activeView === 'joint'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Joint Partners
          </button>
          <button
            type="button"
            onClick={() => setActiveView('banks')}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
              activeView === 'banks'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Bank Summary
          </button>
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={openNewForm}
            className="inline-flex items-center gap-2 rounded-xl bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 active:scale-[0.98] transition whitespace-nowrap shrink-0 min-h-[42px]"
          >
            <Plus className="h-4 w-4" />
            <span>Add Vehicle</span>
          </button>
        </div>
      </header>

      {/* Mobile Compact Top App Bar (48px height, well under 15% cap combined with bottom nav) */}
      <header className="flex md:hidden sticky top-0 z-30 items-center justify-between gap-3 border-b border-slate-200 bg-white/90 backdrop-blur-md px-4 h-12 no-print">
        <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
          VahanLedger
        </span>
        <PWAInstallButton compact />
      </header>

      {/* Main Content */}
      <main className="flex-1 mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 py-5 md:py-8 pb-24 md:pb-12 space-y-6">
        {/* Workspace Header + Install / Backup Actions */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              {activeView === 'banks'
                ? 'Finance Bank Overview'
                : activeView === 'joint'
                ? 'Joint Ownership Vehicles'
                : 'Vehicle Finance Ledger'}
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              Track vehicle numbers, customers, bank finance, partner shares, and photos or videos offline.
            </p>
          </div>

          <div className="hidden md:flex items-center gap-2.5 shrink-0">
            <PWAInstallButton />
            {records.length > 0 && (
              <button
                type="button"
                onClick={handleExportJSON}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors min-h-[40px] whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Backup JSON</span>
              </button>
            )}
          </div>
        </div>

        {/* 4-Column Summary Strip */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <p className="text-xs font-medium text-slate-500">Total Vehicles</p>
            <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {stats.total}
            </p>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <p className="text-xs font-medium text-slate-500">Finance Banks</p>
            <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {stats.banks}
            </p>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <p className="text-xs font-medium text-slate-500">Joint Partnerships</p>
            <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {stats.joint}
            </p>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <p className="text-xs font-medium text-slate-500">Photos &amp; Videos</p>
            <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {stats.media}
            </p>
          </div>
        </section>

        {/* Bank Summary View */}
        {activeView === 'banks' ? (
          <section className="space-y-4">
            {uniqueBanks.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center">
                <Building2 className="mx-auto h-9 w-9 text-slate-400" />
                <h3 className="mt-3 text-base font-bold text-slate-900">
                  No bank records yet
                </h3>
                <p className="mt-1 text-sm text-slate-500">
                  Add a vehicle entry to see bank-wise finance distribution.
                </p>
                <button
                  type="button"
                  onClick={openNewForm}
                  className="mt-5 inline-flex items-center gap-2 rounded-xl bg-blue-700 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-800 transition-colors min-h-[44px]"
                >
                  <Plus className="h-4 w-4" />
                  <span>Add Vehicle Entry</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {uniqueBanks.map(([bank, count]) => (
                  <button
                    key={bank}
                    type="button"
                    onClick={() => {
                      setSelectedBankFilter(bank);
                      setActiveView('records');
                    }}
                    className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-4 text-left hover:border-blue-700/40 hover:bg-slate-50/50 transition-colors min-h-[72px]"
                  >
                    <div className="min-w-0 pr-3">
                      <p className="font-semibold text-slate-900 truncate">
                        {bank}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-500 tabular-nums">
                        {count} {count === 1 ? 'vehicle' : 'vehicles'} financed
                      </p>
                    </div>
                    <ChevronRight className="h-5 w-5 text-slate-400 shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </section>
        ) : (
          <>
            {/* Search & Bank Filter Toolbar */}
            <section className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search vehicle no., customer, partner, or bank..."
                  className="w-full rounded-xl border border-slate-300 bg-white pl-10 pr-4 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-700/20 min-h-[46px]"
                />
              </div>

              <select
                value={selectedBankFilter}
                onChange={(e) => setSelectedBankFilter(e.target.value)}
                aria-label="Filter by finance bank"
                className="rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm font-medium text-slate-800 focus:border-blue-700 focus:outline-none min-h-[46px] sm:w-56"
              >
                <option value="ALL">All Finance Banks</option>
                {uniqueBanks.map(([bank, count]) => (
                  <option key={bank} value={bank}>
                    {bank} ({count})
                  </option>
                ))}
              </select>
            </section>

            {/* Records List / Grid */}
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[1, 2, 3].map((n) => (
                  <div
                    key={n}
                    className="h-40 rounded-2xl border border-slate-200 bg-white animate-pulse"
                  />
                ))}
              </div>
            ) : filteredRecords.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
                <Car className="mx-auto h-10 w-10 text-slate-400" />
                <h3 className="mt-3 text-base font-bold text-slate-900">
                  {records.length === 0
                    ? 'No vehicle entries added yet'
                    : 'No matching vehicle records'}
                </h3>
                <p className="mt-1 text-sm text-slate-500 max-w-md mx-auto">
                  {records.length === 0
                    ? 'Tap below to record your first vehicle number, customer name, finance bank, partner shares, and photos or videos.'
                    : 'Try clearing your search text or selecting All Finance Banks.'}
                </p>
                {records.length === 0 ? (
                  <button
                    type="button"
                    onClick={openNewForm}
                    className="mt-5 inline-flex items-center gap-2 rounded-xl bg-blue-700 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-800 transition-colors min-h-[48px]"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Add First Vehicle</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedBankFilter('ALL');
                      setActiveView('records');
                    }}
                    className="mt-4 inline-flex items-center rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 min-h-[44px]"
                  >
                    Reset Filters
                  </button>
                )}
              </div>
            ) : (
              <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredRecords.map((record) => {
                  const counts = mediaSummary[record.id] ?? {
                    images: 0,
                    videos: 0,
                  };
                  return (
                    <button
                      key={record.id}
                      type="button"
                      onClick={() => setViewingRecord(record)}
                      className="group flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-4 text-left hover:border-blue-700/40 hover:shadow-sm active:scale-[0.99] transition"
                    >
                      <div className="space-y-2.5 w-full">
                        <div className="flex items-start justify-between gap-3">
                          <span className="font-mono text-lg font-bold tracking-wider text-slate-900">
                            {record.vehicleNumber}
                          </span>
                          <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-blue-700 transition-colors shrink-0" />
                        </div>

                        <div>
                          <p className="text-base font-semibold text-slate-900 truncate">
                            {record.customerName}
                          </p>
                          <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                            <span className="font-medium text-slate-700">
                              {record.bankName}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="tabular-nums">
                              {record.partnerCount}{' '}
                              {record.partnerCount === 1 ? 'Partner' : 'Partners'}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-xs text-slate-500 w-full">
                        <span className="tabular-nums truncate">
                          {formatDisplayDateTime(record.dateTime)}
                        </span>

                        {(counts.images > 0 || counts.videos > 0) && (
                          <div className="flex items-center gap-2.5 shrink-0 font-medium text-slate-600 tabular-nums">
                            {counts.images > 0 && (
                              <span className="inline-flex items-center gap-1">
                                <ImageIcon className="h-3.5 w-3.5 text-slate-400" />
                                {counts.images}
                              </span>
                            )}
                            {counts.videos > 0 && (
                              <span className="inline-flex items-center gap-1">
                                <Video className="h-3.5 w-3.5 text-slate-400" />
                                {counts.videos}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </section>
            )}
          </>
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation Bar (56px height + safe-area) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200 bg-white/95 backdrop-blur-md pb-safe no-print"
      >
        <div className="grid grid-cols-4 items-center h-14">
          <button
            type="button"
            onClick={() => {
              setActiveView('records');
              setSelectedBankFilter('ALL');
            }}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
              activeView === 'records' ? 'text-blue-700' : 'text-slate-500'
            }`}
          >
            <Layers className="h-5 w-5" />
            <span className="text-[10px] font-semibold mt-0.5">Records</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('joint')}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
              activeView === 'joint' ? 'text-blue-700' : 'text-slate-500'
            }`}
          >
            <Users className="h-5 w-5" />
            <span className="text-[10px] font-semibold mt-0.5">Partners</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('banks')}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
              activeView === 'banks' ? 'text-blue-700' : 'text-slate-500'
            }`}
          >
            <Building2 className="h-5 w-5" />
            <span className="text-[10px] font-semibold mt-0.5">Banks</span>
          </button>

          <button
            type="button"
            onClick={openNewForm}
            className="flex flex-col items-center justify-center h-full min-h-[44px] text-blue-700"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-700 text-white">
              <Plus className="h-4 w-4" />
            </div>
            <span className="text-[10px] font-semibold mt-0.5">Add</span>
          </button>
        </div>
      </nav>

      {/* Offline Mode Banner */}
      {!isOnline && (
        <div className="fixed bottom-16 md:bottom-4 left-4 z-40 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg no-print">
          <WifiOff className="h-3.5 w-3.5" />
          <span>Offline Mode — Local storage active</span>
        </div>
      )}

      {/* Add / Edit Modal */}
      {isFormOpen && (
        <VehicleFormModal
          editingRecord={editingRecord}
          onClose={() => {
            setIsFormOpen(false);
            setEditingRecord(null);
          }}
          onSave={handleSaveRecord}
        />
      )}

      {/* Detail Modal */}
      {viewingRecord && (
        <VehicleDetailModal
          record={viewingRecord}
          onClose={() => setViewingRecord(null)}
          onEdit={openEditForm}
          onDelete={handleDeleteRecord}
        />
      )}
    </div>
  );
}
