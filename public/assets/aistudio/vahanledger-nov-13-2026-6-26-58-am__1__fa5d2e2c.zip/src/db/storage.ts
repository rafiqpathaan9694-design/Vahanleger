import type { MediaRecord, VehicleRecord } from '../types';

const DB_NAME = 'vahanledger-db';
const DB_VERSION = 1;
const STORE_RECORDS = 'records';
const STORE_MEDIA = 'media';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_RECORDS)) {
        const recordStore = db.createObjectStore(STORE_RECORDS, { keyPath: 'id' });
        recordStore.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_MEDIA)) {
        db.createObjectStore(STORE_MEDIA, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllRecords(): Promise<VehicleRecord[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_RECORDS, 'readonly');
    const store = tx.objectStore(STORE_RECORDS);
    const req = store.getAll();
    req.onsuccess = () => {
      const items = (req.result as VehicleRecord[]) || [];
      items.sort((a, b) => b.updatedAt - a.updatedAt);
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function getMediaByIds(ids: string[]): Promise<MediaRecord[]> {
  if (ids.length === 0) return [];
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_MEDIA, 'readonly');
    const store = tx.objectStore(STORE_MEDIA);
    const results: MediaRecord[] = [];
    let completed = 0;

    ids.forEach((id) => {
      const req = store.get(id);
      req.onsuccess = () => {
        if (req.result) {
          results.push(req.result as MediaRecord);
        }
        completed += 1;
        if (completed === ids.length) {
          resolve(results);
        }
      };
      req.onerror = () => {
        completed += 1;
        if (completed === ids.length) {
          resolve(results);
        }
      };
    });

    tx.onerror = () => reject(tx.error);
  });
}

export async function getAllMediaSummary(): Promise<Record<string, { images: number; videos: number }>> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE_RECORDS, STORE_MEDIA], 'readonly');
    const recReq = tx.objectStore(STORE_RECORDS).getAll();
    const medReq = tx.objectStore(STORE_MEDIA).getAll();

    tx.oncomplete = () => {
      const records = (recReq.result as VehicleRecord[]) || [];
      const mediaList = (medReq.result as MediaRecord[]) || [];
      const mediaTypeMap = new Map<string, 'image' | 'video'>();
      for (const m of mediaList) {
        mediaTypeMap.set(m.id, m.type);
      }

      const summary: Record<string, { images: number; videos: number }> = {};
      for (const r of records) {
        let images = 0;
        let videos = 0;
        for (const mid of r.mediaIds) {
          const t = mediaTypeMap.get(mid);
          if (t === 'image') images += 1;
          else if (t === 'video') videos += 1;
        }
        summary[r.id] = { images, videos };
      }
      resolve(summary);
    };
    tx.onerror = () => reject(tx.error);
  });
}

export async function saveRecordWithMedia(
  record: VehicleRecord,
  newMedia: MediaRecord[],
  removedMediaIds: string[]
): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE_RECORDS, STORE_MEDIA], 'readwrite');
    const recStore = tx.objectStore(STORE_RECORDS);
    const medStore = tx.objectStore(STORE_MEDIA);

    recStore.put(record);
    for (const item of newMedia) {
      medStore.put(item);
    }
    for (const rid of removedMediaIds) {
      medStore.delete(rid);
    }

    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function deleteRecordAndMedia(record: VehicleRecord): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE_RECORDS, STORE_MEDIA], 'readwrite');
    const recStore = tx.objectStore(STORE_RECORDS);
    const medStore = tx.objectStore(STORE_MEDIA);

    recStore.delete(record.id);
    for (const mid of record.mediaIds) {
      medStore.delete(mid);
    }

    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
